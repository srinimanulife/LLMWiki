# Copyright © 2025-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

from coded_tools.agent_network_editor.constants import AGENT_NETWORK_DEFINITION
from coded_tools.agent_network_editor.progress_handler import ProgressHandler


class SetAgentDescription(CodedTool):
    """
    CodedTool implementation which creates or modifies the description of an agent
    of an agent network definition in sly data.

    Agent network definition is a structured representation of an agent network, expressed as a dictionary.
    Each key is an agent name, and its value is an object containing:
    - a description of the agent
    - an instructions to the agent
    - a list of down-chain agents (agents reporting to it)
    """

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """
        :param args: An argument dictionary whose keys are the parameters
                to the coded tool and whose values are the values passed for them
                by the calling agent.  This dictionary is to be treated as read-only.

                The argument dictionary expects the following keys:
                    "agent_name": the name of the agent to update description.
                    "new_description": the new value of description.

        :param sly_data: A dictionary whose keys are defined by the agent hierarchy,
                but whose values are meant to be kept out of the chat stream.

                This dictionary is largely to be treated as read-only.
                It is possible to add key/value pairs to this dict that do not
                yet exist as a bulletin board, as long as the responsibility
                for which coded_tool publishes new entries is well understood
                by the agent chain implementation and the coded_tool implementation
                adding the data is not invoke()-ed more than once.

                Keys expected for this implementation are:
                    "agent_network_definition": an outline of an agent network

        :return:
            In case of successful execution:
                a text string indicating the new value of "description" of the agent has been set.
            otherwise:
                a text string an error message in the format:
                "Error: <error message>"
        """
        network_def: dict[str, Any] = sly_data.get(AGENT_NETWORK_DEFINITION)
        if not network_def:
            return "Error: No network in sly data!"

        the_agent_name: str = args.get("agent_name")
        if not the_agent_name:
            return "Error: No agent_name provided."
        if the_agent_name not in network_def:
            return f"Error: Agent not found: {the_agent_name}"
        # Use "instructions" field existence to determine if it is a function agent
        # instead of "description" field to allow backwards compatibility with agent network definitions
        # that do not have "description" field for function agents
        if network_def[the_agent_name].get("instructions") is None:
            return f"Error: Agent has no instructions field: {the_agent_name}. It is a function agent."

        new_description: str = args.get("new_description")
        if not new_description:
            return "Error: No agent description provided."

        logger = logging.getLogger(self.__class__.__name__)
        logger.info(">>>>>>>>>>>>>>>>>>>Set Agent description>>>>>>>>>>>>>>>>>>")
        logger.info("Agent Name: %s", the_agent_name)
        logger.info("Description: %s", new_description)
        network_def[the_agent_name]["description"] = new_description
        logger.info("The resulting agent network: \n %s", str(network_def))
        sly_data[AGENT_NETWORK_DEFINITION] = network_def

        await ProgressHandler.report_progress(args, network_def)

        logger.debug(">>>>>>>>>>>>>>>>>>> DONE %s !!!>>>>>>>>>>>>>>>>>>", self.__class__.__name__)
        return f"The description for '{the_agent_name}' has been set in 'agent_network_definition' successfully."
