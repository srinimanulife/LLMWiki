
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from __future__ import annotations

from typing import Any
from typing import Dict
from typing import List


class Authorizer:
    """
    An interface for authorization.

    Note that _authorization_ - the ability to determine permission to access a resource (in
    Neuro SAN's case an agent network) - is not to be confused with _authentication_ -
    the ability to determine a user's identity.  Normally, authentication is done by
    a system outside the scope of a Neuro SAN server, like by a load-balancer for a cluster.

    The methods here are based on what we need from what packages like OpenFGA or Oso provide,
    that is to assist in answering the question: "Does Actor X have Persmission Y on Resource Z?"
    It is assumed at this level that the identity of Actor X has already been authenticated
    outside the scope of a Neuro SAN server, if that is desired and necessary.
    """

    async def __aenter__(self) -> Authorizer:
        """
        Opens a scoped session with this Authorizer.
        """
        raise NotImplementedError

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        Closes a scoped session with this Authorizer.
        """
        raise NotImplementedError

    async def authorize(self, actor: Dict[str, Any], action: str, resource: Dict[str, Any]) -> bool:
        """
        :param actor: The actor dictionary with the keys "type" and "id" identifying what
                      is seeking permission.  Most often this is of the form:
                        {
                            "type": "User",
                            "id": "<username>"
                        }
        :param action:  The action for which the user is asking permission for.
                        Most often this is one of the Permission values of:
                            "create", "read", "update" or "delete".
        :param resource: The resource dictionary with the keys "type" and "id" identifying
                      just what is to be authorized for use.  For instance:
                        {
                            "type": "AgentNetwork",
                            "id": "hello_world"
                        }
        :return: True if the actor is allowed to take the requested action on the resource.
                 False otherwise.
        """
        raise NotImplementedError

    async def grant(self, actor: Dict[str, Any], relation: str, resource: Dict[str, Any]) -> bool:
        """
        :param actor: The actor dictionary with the keys "type" and "id" identifying what
                      will be permitted.  Most often this is of the form:
                        {
                            "type": "User",
                            "id": "<username>"
                        }
        :param relation: The relation for which the user will be permitted.
                     Most often this is one of the strings from the Role enum.

        :param resource: The resource dictionary with the keys "type" and "id" identifying
                      just what is to be authorized for use.  For instance:
                        {
                            "type": "AgentNetwork",
                            "id": "hello_world"
                        }
        :return: True if the grant succeeded, False if the grant already existed.
        """
        raise NotImplementedError

    async def revoke(self, actor: Dict[str, Any], relation: str, resource: Dict[str, Any]) -> bool:
        """
        :param actor: The actor dictionary with the keys "type" and "id" identifying what
                      will no longer be permitted.  Most often this is of the form:
                        {
                            "type": "User",
                            "id": "<username>"
                        }
        :param relation: The relation for which the user will no longer be permitted.
                     Most often this is one of the strings from the Role enum.

        :param resource: The resource dictionary with the keys "type" and "id" identifying
                      just what is to be no longer authorized for use.  For instance:
                        {
                            "type": "AgentNetwork",
                            "id": "hello_world"
                        }
        :return: True if the revoke succeeded, False if the revoke already existed.
        """
        raise NotImplementedError

    async def list(self, actor: Dict[str, Any], relation: str, resource: Dict[str, Any]) -> List[str]:
        """
        Return a list of resource ids that the actor has the given relation to,
        as per the graph specified by the authorization model.

        :param actor: The actor dictionary with the keys "type" and "id" identifying what
                      entity's relation should be checked.  Most often this is of the form:
                        {
                            "type": "User",
                            "id": "<username>"
                        }
        :param relation: The relation for which the user's permissions will be checked.
                        Most often this is one of the Permission values of:
                            "create", "read", "update" or "delete".

        :param resource: The resource dictionary with the keys "type" and "id" identifying
                      just what is to be authorized for use.  For instance:
                        {
                            "type": "AgentNetwork",
                            # Note: "id" is not specified. We want a list of these returned.
                        }
        :return: A list of resource ids that the actor has the given relation with.
                 An empty return list implies that the actor has access to no objects
                 of the given resource type.
        """
        raise NotImplementedError

    async def query(self, actor: Dict[str, Any], relation: str, resource: Dict[str, Any]) -> List[str]:
        """
        Instead of a boolean answer from authorize() above, this method gives a list
        of resources of the given resource type (in the dict) that the actor has the
        *direct* given relation to.  This does not take authorization policy graphs
        into account.

        :param actor: The actor dictionary with the keys "type" and "id" identifying what
                      will be permitted.  Most often this is of the form:
                        {
                            "type": "User",
                            "id": "<username>"
                        }
        :param relation: The relation for which the user will be permitted.
                     Most often this is one of the strings from the Role enum.

        :param resource: The resource dictionary with the keys "type" and "id" identifying
                      just what is to be authorized for use.  For instance:
                        {
                            "type": "AgentNetwork",
                            "id": "hello_world"
                        }
        :return: A list of relations (which can be None or empty) that the actor
                has the given relation with.
        """
        raise NotImplementedError
